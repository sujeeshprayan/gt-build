
//-----------OTP Popup

$(".otp-close").click(function(){
    $(".otp-overlay").hide();
});

$("#otp-open").click(function(){
    $(".otp-overlay").show();
});

//-----------Edit Popup

$(".edit-close").click(function(){
    $("#teacher-aboout").hide();
});

$("#edit-teacher-about").click(function(){
    $("#teacher-aboout").show();
});
//-----------Edit Popup

$(".edit-close").click(function(){
    $("#teacher-highlights").hide();
});

$("#edit-teacher-highlights").click(function(){
    $("#teacher-highlights").show();
});
//-----------Edit My Videos Popup

$(".edit-close").click(function(){
    $("#my-vdos").hide();
});

$("#edit-my-vdos").click(function(){
    $("#my-vdos").show();
});

//-----------Edit My Videos Popup

$(".edit-close").click(function(){
    $("#teacher-facilities").hide();
});

$("#edit-facilities").click(function(){
    $("#teacher-facilities").show();
});
//-----------Edit My Videos Popup

$(".edit-close").click(function(){
    $("#teacher-credentials").hide();
});

$("#edit-credentials").click(function(){
    $("#teacher-credentials").show();
});
//-----------Edit Teacher Profile Popup

$(".edit-close").click(function(){
    $("#teacher-profile").hide();
});

$("#edit-teacher-profile").click(function(){
    $("#teacher-profile").show();
});
//*------- Login Flip



$("#open-forgot").click(function(){
    $("#forgot-box").show();
   $("#login-box").hide();
});
$("#forgot-back").click(function(){
    $("#forgot-box").hide();
   $("#login-box").show();
});


//*-------- Video Slider
  $(document).on('ready', function() {
     
      $(".lazy").slick({
        lazyLoad: 'ondemand', // ondemand progressive anticipated
        infinite: true
      });
    });
  
//----------------Tab
$(function() {
  var $tabButtonItem = $('#tab-button li'),
      $tabSelect = $('#tab-select'),
      $tabContents = $('.tab-contents'),
      activeClass = 'is-active';

  $tabButtonItem.first().addClass(activeClass);
  $tabContents.not(':first').hide();

  $tabButtonItem.find('a').on('click', function(e) {
    var target = $(this).attr('href');

    $tabButtonItem.removeClass(activeClass);
    $(this).parent().addClass(activeClass);
    $tabSelect.val(target);
    $tabContents.hide();
    $(target).show();
    e.preventDefault();
  });

  $tabSelect.on('change', function() {
    var target = $(this).val(),
        targetSelectNum = $(this).prop('selectedIndex');

    $tabButtonItem.removeClass(activeClass);
    $tabButtonItem.eq(targetSelectNum).addClass(activeClass);
    $tabContents.hide();
    $(target).show();
  });
}); 


//--------- Choose Courses
$(document).ready(function(){
    $("#choose-courses-btn").click(function(){
        $("#view-courses").toggle();
    });
});

//--------- Choose Courses
$(document).ready(function(){
    $(".chat-drop-click").click(function(){
        $("#chat-top-drop").toggle();
    });
});


//--------- Contact List Drop
$(document).ready(function(){
    $("#list-drop").click(function(){
        $("#list-drop-open").toggle();
    });
});
// 

document.querySelector('.chat[data-chat=person2]').classList.add('active-chat');
document.querySelector('.person[data-chat=person2]').classList.add('active');

friends = {
    list: document.querySelector('ul.people'),
    all: document.querySelectorAll('.left .person'),
    name: ''
  },
  chat = {
    container: document.querySelector('.chat-wrap .right'),
    current: null,
    person: null,
    name: document.querySelector('.chat-wrap .right .top .name')
  };

//friends.all.forEach(f => {
//  f.addEventListener('mousedown', () => {
//    f.classList.contains('active') || setAciveChat(f)
//  })
//});

friends.all.forEach(function(f){
    f.addEventListener('mousedown', function(){
        f.classList.contains('active') || setAciveChat(f);
    });
});

function setAciveChat(f) {
  friends.list.querySelector('.active').classList.remove('active');
  f.classList.add('active');
  chat.current = chat.container.querySelector('.active-chat');
  chat.person = f.getAttribute('data-chat');
  chat.current.classList.remove('active-chat');
  chat.container.querySelector('[data-chat="' + chat.person + '"]').classList.add('active-chat');
  friends.name = f.querySelector('.name').innerText;
  chat.name.innerHTML = friends.name;
}

